from kineticspy.robobj import robot
